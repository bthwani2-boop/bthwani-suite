# DSH Phase 1.1 Forensic Review — Registry Evidence Closure

**Decision:** `FIX_REQUIRED`  
**Review date:** 2026-05-21  
**Input repo snapshot:** `bthwani-suite-ghb-0163-20260521-055416-gitattributes-dsh (1).zip`  
**Input evidence:** `DSH_PHASE_1_1_REGISTRY_EVIDENCE_CLOSURE-20260521-061309.zip`  
**Scope:** Review Phase 1.1 execution and decide whether it can be accepted as 100% closed.

---

## 1. Executive Verdict

Phase 1.1 is directionally correct and materially improved Phase 1, but it is **not 100% closed**.

It fixed important problems:
- Registry exists as shared metadata.
- Partner operational flow count is corrected in source to 27.
- Hidden compat runtime guard is present in `PartnerSupportScreen.tsx`.
- Registry validation helpers are present.
- Source changes are narrow: 4 source files.
- Evidence reports `tsc-noEmit exit 0`, `guard:tamagui-import-boundary PASS`, and `guard:i18n-direction:mobile-control-panel PASS`.

But it still has evidence and baseline issues:
- Evidence summary/CSV numeric counts do not match the actual registry source.
- Registry consumption remains limited to app-partner + shared barrel; app-client/app-captain/app-field/control-panel are still deferred.
- Source ZIP after GitHub upload includes two plan/review artifacts that Phase 1.1 evidence listed as untracked at generation time; evidence is therefore stale relative to the uploaded snapshot.
- `operations-support.preview.ts` remains a parallel support issue category model not yet integrated with the new flow registry.

**Final decision:** `FIX_REQUIRED` before moving to Phase 2.

---

## 2. Numeric Source Snapshot

| Metric | Count |
|---|---:|
| Total files in uploaded repo snapshot | 1194 |
| DSH frontend files scanned | 269 |
| Registry entries parsed from `dsh-flow-registry.ts` | 40 |
| Duplicate registry IDs | 0 |
| Missing required registry fields | 0 |
| `DSH_PARTNER_OPERATIONAL_FLOW_IDS` count | 27 |
| Operational IDs missing from registry | 0 |
| Registry hidden-compat entries | 8 |
| Finance-preview entries | 3 |
| Registry consumer files detected | 4 |
| Direct Tamagui imports under `dsh/frontend` | 0 |
| Hardcoded color/rgba findings under `dsh/frontend` | 12 |
| `space-between` risk files under `dsh/frontend` | 55 |
| TODO/legacy/placeholder/fallback/mock/fixture keyword files under `dsh/frontend` | 79 |

---

## 3. Registry Source Validation

Actual values parsed from source:

| Check | Actual |
|---|---:|
| Total entries | 40 |
| `primary` visibility | 24 |
| `contextual` visibility | 7 |
| `hidden-compat` visibility | 8 |
| `internal` visibility | 1 |
| `ownerSurface=app-partner` | 25 |
| `ownerSurface=app-client` | 3 |
| `ownerSurface=app-captain` | 4 |
| `ownerSurface=app-field` | 3 |
| `ownerSurface=control-panel` | 2 |
| `ownerSurface=wlt-finance` | 3 |
| `financialImpact=true` | 3 |
| `escalationOwner` present | 26 |

**Registry IDs:**

```text
order-accept
order-get
order-handoff
order-prepare
order-ready
order-out-for-delivery
order-store-delivered
order-reject
order-issue-queue
order-alerts
order-sla-risk
order-issue-required
auction-status-update
order-rejection
order-chat-send
order-chat-read-ack
order-quick-reply-config
order-quick-reply-settings
order-quick-reply-setup
inventory-adjust
inventory-update
items-upsert
doc-upload
intake-start
store-nomination
video-upload
partner-finance-bridge
partner-settlement-summary
partner-commission-summary
client-order-tracking
client-cart-checkout
client-order-issue
captain-order-pickup
captain-proof-of-delivery
captain-map-navigation
field-store-onboarding
field-store-visit
field-readiness-escalation
control-sla-policy
control-escalation-queue
```

---

## 4. Evidence Accuracy Check

Phase 1.1 evidence claims:

| Evidence claim | Claimed |
|---|---:|
| total entries | 40 |
| primary visibility | 22 |
| contextual visibility | 8 |
| hidden compat | 8 |
| internal | 1 |
| partner owned | 24 |

Actual source parsing:

| Source fact | Actual |
|---|---:|
| total entries | 40 |
| primary visibility | 24 |
| contextual visibility | 7 |
| hidden compat | 8 |
| internal | 1 |
| partner owned | 25 |

**Mismatch:** evidence still contains numeric inaccuracies. This blocks any 100% closure claim.

---

## 5. Scope and Changed Files

Evidence says source changes were limited to:

```text
dsh/frontend/shared/dsh-flow-registry.ts
dsh/frontend/shared/index.ts
dsh/frontend/app-partner/dsh-partner.types.ts
dsh/frontend/app-partner/screens/PartnerSupportScreen.tsx
```

This is consistent with Phase 1.1 being a narrow registry/evidence closure phase.

However, uploaded repo snapshot also contains:
```text
tools/plan/bthwani_all_apps_dsh/DSH_PHASE_1_1_REGISTRY_EVIDENCE_CLOSURE_PROMPT.md
tools/plan/bthwani_all_apps_dsh/DSH_PHASE_1_FORENSIC_REVIEW_REPORT.md
```

Those were listed as untracked in the evidence package. After GitHub upload they appear inside the source snapshot. This is not a runtime/source blocker, but it means the evidence package is stale relative to the uploaded branch snapshot.

---

## 6. Registry Consumption

Detected registry consumers:

```text
dsh/frontend/app-partner/dsh-partner.types.ts
dsh/frontend/shared/dsh-flow-registry.ts
dsh/frontend/shared/index.ts
dsh/frontend/app-partner/screens/PartnerSupportScreen.tsx
```

Status:
- `dsh-flow-registry.ts`: source of registry.
- `shared/index.ts`: barrel export.
- `dsh-partner.types.ts`: independent operational IDs and count constant; no direct registry import to avoid circular risk.
- `PartnerSupportScreen.tsx`: uses `isDshHiddenCompatFlow` runtime guard.

Remaining:
- app-client: no registry consumption.
- app-captain: no registry consumption.
- app-field: no registry consumption.
- control-panel: no registry consumption.
- WLT: no registry consumption.

This is acceptable for Phase 1.1 only. It is not enough for DSH system closure.

---

## 7. Hidden Compat Review

Registry hidden-compat entries:

```text
auction-status-update
order-alerts
order-issue-required
order-rejection
order-sla-risk
partner-commission-summary
partner-finance-bridge
partner-settlement-summary
```

Partner operational hidden compat list:

```text
order-alerts
order-issue-required
order-sla-risk
partner-commission-summary
partner-finance-bridge
partner-settlement-summary
```

Support-route hidden compat list:

```text
auction-status-update
```

Notes:
- `auction-status-update` and `order-rejection` are hidden-compat in registry but not in `DSH_PARTNER_HIDDEN_COMPAT_OPERATIONAL_FLOW_IDS` because they are legacy aliases outside `DSH_PARTNER_OPERATIONAL_FLOW_IDS`.
- `order-rejection` still exists as a `DshPartnerRoute` and is routed in `DshPartnerSurface.tsx` to `OrderIssueScreen`. This is acceptable as compatibility routing, but must not be rendered as a primary user entry.
- `DshPartnerOrderRejectionScreen.tsx` still exists and is referenced by screen registry, while `DshPartnerSurface.tsx` no longer imports it. This is a future reachability/legacy cleanup item, not a Phase 1.1 blocker.

---

## 8. Operations Support Preview Duplication Risk

`dsh/frontend/shared/operations-support.preview.ts` has 17 support issue/category IDs.

Only 2 overlap with `DSH_FLOW_REGISTRY`:
```text
auction-status-update
order-rejection
```

Operations-support IDs not in registry:
```text
branch-readiness-escalation
catalog-barcode-issue
courier-not-arrived
customer-not-responding
delayed-preparation
delivery-failed
field-proof-required
handoff-mismatch
item-unavailable
partner-reject-request
payment-refund-review
proof-of-delivery
store-nomination-intake
store-wait-time
wrong-item
```

This confirms that Phase 1.1 did not yet unify issue-category preview logic with the shared flow registry. That is acceptable only if Phase 2 explicitly aligns issue categories to registry entries or establishes a clear two-layer model:
- flow registry = cross-surface route/owner/visibility/on-demand SSoT
- operations support preview = issue category/case preview model linked by flow/reference

Without that alignment, duplication and drift risk remain.

---

## 9. UI/UX / Boundary Scan

| Check | Result |
|---|---|
| Direct Tamagui imports under `dsh/frontend` | 0 |
| Hardcoded color/rgba candidate files | 12 |
| `space-between` risk files | 55 |
| legacy/TODO/placeholder/mock/fallback keyword files | 79 |

Direct Tamagui imports:
```text
None detected
```

Hardcoded color/rgba candidate files:
```text
dsh/frontend/app-captain/DshCaptainSurface.tsx
dsh/frontend/shared/banner.preview-store.ts
dsh/frontend/control-panel/shared/journeyFixtures.ts
dsh/frontend/control-panel/platform/Appearance/appearance.preview.ts
dsh/frontend/control-panel/platform/Services/services.preview.ts
dsh/frontend/app-partner/parts/PartnerOrderAlertsPanel.tsx
dsh/frontend/app-partner/screens/DshPartnerOrderRejectionScreen.tsx
dsh/frontend/app-partner/screens/OrdersInboxScreen.tsx
dsh/frontend/app-client/parts/ApprovedVideoReelsViewer.tsx
dsh/frontend/app-client/screens/BellScreen.tsx
dsh/frontend/app-client/screens/HomeScreen.tsx
dsh/frontend/app-client/screens/StoreScreen.tsx
```

This is not Phase 1.1 scope, but it proves the full DSH UI closure is still not complete.

---

## 10. Verification Evidence

Evidence package reports:

```text
tsc-noemit.txt: exit 0 — no errors
guard-tamagui-import-boundary.txt: UI-ARCH-BOUNDARY: PASS (fail=0, warn=0)
guard-i18n-direction-mobile-control-panel.txt: Central i18n/direction guard passed.
git-diff-check.txt: empty output
git-staged-diff-check.txt: empty output
```

This supports: implementation did not fail reported gates.

It does not support:
- full DSH closure.
- all surfaces consuming registry.
- visual/UI closure.
- control-panel alignment.
- local Git state after final GitHub upload.

---

## 11. Decision

`FIX_REQUIRED`

Reasons:
1. Numeric evidence mismatch remains.
2. Evidence ZIP is stale relative to uploaded repo snapshot because previously untracked plan artifacts are now present.
3. Registry is not yet consumed across app-client/app-captain/app-field/control-panel.
4. Operations support preview remains parallel and not linked to registry.
5. DSH UI/UX and on-demand closure remain future phases.

---

## 12. Required Next Step

Do **not** start broad Phase 2 yet.

Start:

`PHASE_1_2_REGISTRY_EVIDENCE_AND_ISSUE_CATEGORY_ALIGNMENT_AUDIT`

Goal:
- Correct evidence numeric counts using real `getDshFlowRegistryStats()`.
- Add a machine-readable validation artifact that is generated from source, not manually typed.
- Confirm final GitHub snapshot status after commit.
- Audit relation between `dsh-flow-registry.ts` and `operations-support.preview.ts`.
- Decide whether issue categories remain separate or get mapped to registry flows.
- Do not change UI yet.
