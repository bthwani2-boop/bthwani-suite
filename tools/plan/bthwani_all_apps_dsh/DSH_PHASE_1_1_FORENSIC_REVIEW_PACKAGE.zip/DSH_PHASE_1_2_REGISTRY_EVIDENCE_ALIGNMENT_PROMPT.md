# DSH Phase 1.2 — Registry Evidence + Issue Category Alignment Audit

نفّذ هذه المرحلة داخل C:\bthwani-suite.

## Decision Context

Phase 1.1 حسّن registry وأغلق جزءًا من evidence، لكنه لا يثبت إغلاق 100% لأن هناك mismatch رقمي بين evidence والـ source، ولأن `operations-support.preview.ts` ما زال parallel issue/category model غير مرتبط بالكامل بـ `dsh-flow-registry.ts`.

## المهمة

نفّذ Phase 1.2 فقط:

`DSH_PHASE_1_2_REGISTRY_EVIDENCE_AND_ISSUE_CATEGORY_ALIGNMENT_AUDIT`

هذه مرحلة Audit + deterministic evidence correction فقط. لا تبدأ UI ولا cross-surface consumption implementation.

يجب قبل التنفيذ الاطلاع على ملفات الوكلاء والـ skills ذات العلاقة وتطبيق ما يخص المهمة منها بدقة، وعدم الاعتماد على الذاكرة أو الافتراض.

## النطاق

افحص وعدّل فقط عند الضرورة المثبتة:

- `dsh/frontend/shared/dsh-flow-registry.ts`
- `dsh/frontend/shared/operations-support.preview.ts`
- `dsh/frontend/shared/index.ts`
- `dsh/frontend/app-partner/dsh-partner.types.ts`
- `dsh/frontend/app-partner/screens/PartnerSupportScreen.tsx`
- `tools/plan/bthwani_all_apps_dsh/**` فقط لتصحيح/إضافة تقرير phase الحالي إن كان مطلوبًا
- `tools/registry/runs/{SESSION_ID}/**` للأدلة فقط

## ممنوع

- ممنوع تعديل app-client/app-captain/app-field/control-panel في هذه المرحلة.
- ممنوع UI redesign.
- ممنوع backend/API/runtime/database.
- ممنوع dependencies أو lockfile.
- ممنوع broad refactor.
- ممنوع إنشاء design system محلي.
- ممنوع import Tamagui خارج @bthwani/ui-kit.
- ممنوع claim PASS/CLOSED/100%.
- لا تستخدم أو تذكر أي مسار/ريبو قديم باسم bth؛ الريبو الحالي والمعتمد فقط هو C:\bthwani-suite.

## CHECK المطلوب

1. استخرج registry stats من المصدر نفسه، لا من أرقام مكتوبة يدويًا:
   - totalEntries
   - primaryCount
   - contextualCount
   - hiddenCompatCount
   - internalCount
   - financePreviewCount
   - escalationOwnerCount
   - partnerOwnedCount
   - owner count by surface
   - domain count by domain
   - onDemandPolicy count by policy

2. تحقق من:
   - no duplicate IDs
   - no missing required fields
   - all `financialImpact=true` have `onDemandPolicy='finance-preview-only'`
   - all `hiddenCompat=true` have `visibility='hidden-compat'`
   - all `DSH_PARTNER_OPERATIONAL_FLOW_IDS` have registry entries
   - hidden-compat aliases outside operational IDs are documented

3. افحص العلاقة بين:
   - `dsh/frontend/shared/dsh-flow-registry.ts`
   - `dsh/frontend/shared/operations-support.preview.ts`

اكتب mapping:
- issueCategory/flow preview id
- related registry flow id إن وجد
- owner surface
- escalation owner
- should remain issue-category only? yes/no
- should map to registry flow? yes/no
- recommended phase

4. افحص final GitHub/local status:
   - هل plan artifacts tracked أم untracked؟
   - هل evidence output متزامن مع source snapshot؟
   - هل يوجد staged/untracked غير محسوب؟

## APPLY المسموح

فقط إذا ثبت mismatch في source comments أو plan docs:
- صحح الأرقام المكتوبة في comments أو reports.
- أضف helper pure/read-only إذا كان ضروريًا لتوليد stats.
- لا تغيّر runtime UI behavior.
- لا تغيّر route behavior.
- لا توسع registry لمجرد إضافة issue categories إلا إذا كان mapping ضروريًا ومثبتًا.

## Evidence المطلوب

أنشئ:

`tools/registry/runs/{SESSION_ID}/`

ويحتوي:

- `SUMMARY.md`
- `registry-source-stats.json`
- `registry-validation.csv`
- `registry-vs-evidence-check.csv`
- `operations-support-to-registry-map.csv`
- `git-status.txt`
- `git-diff-stat.txt`
- `git-diff-name-status.txt`
- `git-diff-check.txt`
- `git-staged-name-status.txt`
- `git-staged-diff-check.txt`
- `git-untracked-files.txt`
- `tsc-noemit.txt`
- `guard-tamagui-import-boundary.txt`
- `guard-i18n-direction-mobile-control-panel.txt`
- `{SESSION_ID}.zip`

## Verification

شغّل:

```powershell
Set-Location -LiteralPath "C:\bthwani-suite"
git --no-pager status --short
git --no-pager diff --stat
git --no-pager diff --name-status
git --no-pager diff --check
git --no-pager diff --cached --name-status
git --no-pager diff --cached --check
git ls-files --others --exclude-standard
pnpm -w exec tsc --noEmit
pnpm run guard:tamagui-import-boundary
pnpm run guard:i18n-direction:mobile-control-panel
```

## شروط القبول

- أرقام evidence تطابق source stats.
- لا توجد أرقام manual متناقضة.
- registry validation clean.
- كل operational IDs مغطاة.
- العلاقة بين operations-support issue categories و registry واضحة ومجدولة.
- no source behavior change إلا إذا كان تصحيحًا موثقًا.
- لا يبدأ Phase 2 حتى يكون هذا مغلقًا.

## الرد النهائي المطلوب

- Decision: READY_FOR_PHASE_2_PROMPT / FIX_REQUIRED / NEEDS_EVIDENCE / BLOCKED
- SESSION_ID
- changed files
- source stats
- mismatches fixed
- operations-support mapping summary
- verification results
- zip path
- لا تدّعي PASS/CLOSED/100%.
